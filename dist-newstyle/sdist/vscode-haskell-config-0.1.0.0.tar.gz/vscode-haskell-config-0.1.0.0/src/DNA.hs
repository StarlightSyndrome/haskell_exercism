module DNA (nucleotideCounts, Nucleotide(..)) where
-- module DNA (toRNA) where
import Data.Map (Map)

data Nucleotide = A | C | G | T deriving (Eq, Ord, Show)

nucleotideCounts :: String -> Either String (Map Nucleotide Int)
nucleotideCounts xs = traverse countN
    where
        countN :: Char -> Either Char Nucleotide
        countN 'A' = pure (Nucleotide A)



mapN :: Char -> Either Char Nucleotide
mapN c
  | 'A' = pure A
  | 'C' = pure C
  | 'G' = pure G
  | 'T' = pure T
  | otherwise = Left c
